// define the Calculator functions
//console.log("generated-javascript -- index.js -- start");
exports.CalculatorLexer = require('generated-javascript/CalculatorLexer').CalculatorLexer;
exports.CalculatorParser = require('generated-javascript/CalculatorParser').CalculatorParser;
exports.CalculatorListener = require('generated-javascript/CalculatorListener').CalculatorListener;
//console.log("generated-javascript -- index.js -- end");
